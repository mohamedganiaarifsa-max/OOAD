import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { DemoCredentialsModal } from '../Navigation';
import {
  PawPrint,
  Mail,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowRight,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';

export const UniversalLoginPage: React.FC<{ initialEmail?: string; initialPassword?: string }> = ({
  initialEmail = '',
  initialPassword = '',
}) => {
  const { login, user, isAuthenticated, navigate } = useAuth();
  const [email, setEmail] = useState(initialEmail || 'admin@petcare.com');
  const [password, setPassword] = useState(initialPassword || 'admin123');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);

  // If authenticated, navigate to designated role dashboard
  useEffect(() => {
    if (isAuthenticated && user) {
      navigate(`/${user.role}/dashboard`);
    }
  }, [isAuthenticated, user, navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const res = login(email, password);
      if (!res.success) {
        setError(res.error || 'Invalid credentials. Please verify your email and password.');
        setIsSubmitting(false);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication error occurred.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 px-4 sm:px-6 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/3 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center z-10 mb-6">
        <div className="flex items-center justify-center gap-2.5 mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center text-white shadow-lg shadow-teal-500/30">
            <PawPrint className="w-6 h-6" />
          </div>
          <div className="text-left">
            <span className="text-2xl font-black text-white tracking-tight leading-none block">
              PetCare <span className="text-xs uppercase font-extrabold text-teal-300">Smart</span>
            </span>
            <span className="text-[11px] text-slate-400">Management System</span>
          </div>
        </div>
        <h1 className="text-xl font-bold text-white tracking-tight mt-2">Universal Sign-In</h1>
        <p className="text-xs text-slate-400 mt-1">
          Enter your credentials to securely access your designated role workspace.
        </p>
      </div>

      {/* Login Card */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="bg-white rounded-3xl shadow-2xl p-6 sm:p-8 border border-slate-100">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-800 text-xs">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{error}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <div className="relative rounded-xl">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@petcare.com"
                  className="block w-full pl-10 pr-3.5 py-2.5 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Password
              </label>
              <div className="relative rounded-xl">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="block w-full pl-10 pr-10 py-2.5 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-md shadow-teal-600/20 transition flex items-center justify-center gap-2 text-xs tracking-wider uppercase mt-2 disabled:opacity-50"
            >
              <span>{isSubmitting ? 'Authenticating...' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Demo Helper Button */}
          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-medium">Testing & Demo Accounts:</span>
            <button
              type="button"
              onClick={() => setShowDemoModal(true)}
              className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1.5 px-2.5 py-1 bg-teal-50 hover:bg-teal-100 rounded-lg transition"
            >
              <KeyRound className="w-3.5 h-3.5 text-teal-600" />
              <span>Demo Logins</span>
            </button>
          </div>
        </div>
      </div>

      <DemoCredentialsModal
        isOpen={showDemoModal}
        onClose={() => setShowDemoModal(false)}
        onSelect={(demEmail, demPass) => {
          setEmail(demEmail);
          setPassword(demPass);
        }}
      />
    </div>
  );
};

// Aliases for route compatibility
export const AdminLoginPage: React.FC = () => (
  <UniversalLoginPage initialEmail="admin@petcare.com" initialPassword="admin123" />
);

export const DoctorLoginPage: React.FC = () => (
  <UniversalLoginPage initialEmail="doctor@petcare.com" initialPassword="doctor123" />
);

export const StaffLoginPage: React.FC = () => (
  <UniversalLoginPage initialEmail="staff@petcare.com" initialPassword="staff123" />
);

export const OwnerLoginPage: React.FC = () => (
  <UniversalLoginPage initialEmail="owner@petcare.com" initialPassword="owner123" />
);

export const LoginPage = UniversalLoginPage;
