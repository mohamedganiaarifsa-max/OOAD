import React, { useState } from 'react';
import { useAuth } from '../AuthContext';
import { DataService, AuthService } from '../services';
import {
  PawPrint,
  Home,
  Users2,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Stethoscope,
  HeartPulse,
  Pill,
  Syringe,
  FileText,
  Activity,
  PlusCircle,
  UtensilsCrossed,
  Check,
  CreditCard,
  Camera,
  CheckCircle2,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { user, navigate, resetDemoData } = useAuth();
  const pets = DataService.getPets();
  const bookings = DataService.getBookings();
  const invoices = DataService.getInvoices();
  const users = AuthService.getAllUsers();
  const telemetry = DataService.getTelemetry();

  const totalRev = invoices.reduce((s, i) => s + (i.status === 'Paid' ? i.total : 0), 0);
  const boarded = pets.filter((p) => p.isBoarded).length;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-lg">
        <span className="text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30">
          Admin Control Center
        </span>
        <h1 className="text-2xl font-black mt-2">Welcome, {user?.name || 'Administrator'}</h1>
        <p className="text-xs text-slate-300 mt-1">Full clinic operations, staff roster, and facility occupancy.</p>
        <div className="flex gap-2 mt-4">
          <button onClick={() => navigate('/pets')} className="px-3.5 py-1.5 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl">
            Manage Pets
          </button>
          <button onClick={() => navigate('/users')} className="px-3.5 py-1.5 bg-white/10 text-white font-semibold text-xs rounded-xl">
            Staff & Users
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Pets</span>
          <div className="text-xl font-black text-slate-800 mt-1">{pets.length}</div>
          <span className="text-[11px] text-teal-600 font-medium">{boarded} Boarded on-site</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Occupancy</span>
          <div className="text-xl font-black text-slate-800 mt-1">{Math.round((boarded / 12) * 100)}%</div>
          <span className="text-[11px] text-slate-500">12 Total luxury suites</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Revenue</span>
          <div className="text-xl font-black text-emerald-600 mt-1">${totalRev.toFixed(2)}</div>
          <span className="text-[11px] text-emerald-600 font-medium">All invoices balanced</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Staff Accounts</span>
          <div className="text-xl font-black text-slate-800 mt-1">{users.length}</div>
          <span className="text-[11px] text-slate-500">Active personnel</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-bold text-sm text-slate-800">Current Boarding Guests</h2>
            <button onClick={() => navigate('/boarding')} className="text-xs text-teal-600 font-bold">View All</button>
          </div>
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b text-slate-400 pb-2">
                  <th className="pb-2">Guest</th>
                  <th className="pb-2">Suite</th>
                  <th className="pb-2">Dates</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-2.5 font-bold">{b.petName}</td>
                    <td className="py-2.5 font-mono">{b.roomNumber}</td>
                    <td className="py-2.5 text-slate-500">{b.checkInDate} → {b.checkOutDate}</td>
                    <td className="py-2.5"><span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 font-bold">{b.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <div className="flex justify-between items-center">
            <h2 className="font-bold text-sm text-slate-800">Live Biometrics</h2>
            <button onClick={() => navigate('/smart-monitor')} className="text-xs text-teal-600 font-bold">Monitor</button>
          </div>
          {telemetry.map((t) => (
            <div key={t.petId} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
              <div className="flex justify-between font-bold mb-1">
                <span>{t.petName}</span>
                <span className="text-[10px] text-teal-700 font-mono">{t.roomNumber}</span>
              </div>
              <div className="flex justify-between text-slate-500 text-[11px]">
                <span>Pulse: {t.heartRate} bpm</span>
                <span>Temp: {t.bodyTemp}°C</span>
                <span>{t.activityLevel}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const DoctorDashboard: React.FC = () => {
  const { user, navigate } = useAuth();
  const pets = DataService.getPets();
  const meds = DataService.getMedications();
  const records = DataService.getMedicalRecords();

  return (
    <div className="space-y-6">
      <div className="bg-emerald-950 rounded-3xl p-6 text-white shadow-lg">
        <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
          Clinical Queue
        </span>
        <h1 className="text-2xl font-black mt-2">Welcome, {user?.name || 'Dr. Marcus Vance, DVM'}</h1>
        <p className="text-xs text-slate-300 mt-1">Review patient medical records, active medications, and diagnostics.</p>
        <div className="flex gap-2 mt-4">
          <button onClick={() => navigate('/records')} className="px-3.5 py-1.5 bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl">
            Medical Records
          </button>
          <button onClick={() => navigate('/medications')} className="px-3.5 py-1.5 bg-white/10 text-white font-semibold text-xs rounded-xl">
            Prescriptions
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h2 className="font-bold text-sm text-slate-800 mb-3">Recent Patient Diagnoses</h2>
          <div className="space-y-3">
            {records.map((r) => (
              <div key={r.id} className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
                <div className="flex justify-between font-bold">
                  <span>{r.petName}</span>
                  <span className="text-slate-400 font-mono">{r.date}</span>
                </div>
                <div className="text-teal-700 font-medium">{r.diagnosis}</div>
                <div className="text-slate-500 text-[11px]">{r.treatmentPlan}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h2 className="font-bold text-sm text-slate-800 mb-3">Active Prescriptions</h2>
          <div className="space-y-2.5">
            {meds.map((m) => (
              <div key={m.id} className="p-3 bg-slate-50 rounded-xl text-xs flex justify-between items-center">
                <div>
                  <div className="font-bold text-slate-800">{m.name}</div>
                  <div className="text-slate-500 text-[11px]">{m.dosage} • {m.frequency}</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700 font-bold text-[10px]">{m.petName}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const StaffDashboard: React.FC = () => {
  const { user, navigate } = useAuth();
  const [feedings, setFeedings] = useState(() => DataService.getFeedings());
  const [meds, setMeds] = useState(() => DataService.getMedications());

  const handleToggleFeed = (id: string) => {
    DataService.toggleFeedingCompleted(id, user?.name || 'Staff');
    setFeedings(DataService.getFeedings());
  };

  const handleToggleMed = (id: string) => {
    DataService.toggleMedicationGiven(id);
    setMeds(DataService.getMedications());
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-950 rounded-3xl p-6 text-white shadow-lg">
        <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded border border-blue-500/30">
          Boarding & Care Staff
        </span>
        <h1 className="text-2xl font-black mt-2">Welcome, {user?.name || 'Elena Rostova'}</h1>
        <p className="text-xs text-slate-300 mt-1">Daily feeding checklists and medication rounds.</p>
        <div className="flex gap-2 mt-4">
          <button onClick={() => navigate('/feeding')} className="px-3.5 py-1.5 bg-blue-500 text-slate-950 font-bold text-xs rounded-xl">
            Feeding Schedule
          </button>
          <button onClick={() => navigate('/grooming')} className="px-3.5 py-1.5 bg-white/10 text-white font-semibold text-xs rounded-xl">
            Grooming Tasks
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h2 className="font-bold text-sm text-slate-800 mb-3">Today's Feeding Rounds</h2>
          <div className="space-y-2.5">
            {feedings.map((f) => (
              <div key={f.id} className="p-3 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-slate-800">{f.petName}</span> ({f.mealType})
                  <div className="text-slate-500 text-[11px]">{f.foodBrand} • {f.portionGrams}g</div>
                </div>
                <button
                  onClick={() => handleToggleFeed(f.id)}
                  className={`px-3 py-1 rounded-lg font-bold text-[11px] ${
                    f.isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-600 text-white'
                  }`}
                >
                  {f.isCompleted ? 'Done' : 'Serve'}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h2 className="font-bold text-sm text-slate-800 mb-3">Medication Administration</h2>
          <div className="space-y-2.5">
            {meds.map((m) => (
              <div key={m.id} className="p-3 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-slate-800">{m.name}</span>
                  <div className="text-slate-500 text-[11px]">{m.petName} • {m.dosage}</div>
                </div>
                <button
                  onClick={() => handleToggleMed(m.id)}
                  className={`px-3 py-1 rounded-lg font-bold text-[11px] ${
                    m.isGivenToday ? 'bg-emerald-100 text-emerald-800' : 'bg-teal-600 text-white'
                  }`}
                >
                  {m.isGivenToday ? 'Given' : 'Give Dose'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const OwnerDashboard: React.FC = () => {
  const { user, navigate } = useAuth();
  const allPets = DataService.getPets();
  const myPets = allPets.filter((p) => p.ownerName.includes('Miller') || p.ownerId === user?.id || user?.email === 'owner@petcare.com');
  const telemetry = DataService.getTelemetry().filter((t) => myPets.some((p) => p.id === t.petId));
  const invoices = DataService.getInvoices().filter((i) => myPets.some((p) => p.id === i.petId));

  const handlePay = (id: string) => {
    DataService.markInvoicePaid(id, 'Credit Card');
  };

  return (
    <div className="space-y-6">
      <div className="bg-amber-950 rounded-3xl p-6 text-white shadow-lg">
        <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
          Pet Parent Portal
        </span>
        <h1 className="text-2xl font-black mt-2">Welcome, {user?.name || 'David & Clara Miller'}</h1>
        <p className="text-xs text-slate-300 mt-1">Live status of your boarded pets, medical records, and stay invoices.</p>
        <div className="flex gap-2 mt-4">
          <button onClick={() => navigate('/smart-monitor')} className="px-3.5 py-1.5 bg-amber-400 text-slate-950 font-bold text-xs rounded-xl">
            Live Suite Camera
          </button>
          <button onClick={() => navigate('/boarding')} className="px-3.5 py-1.5 bg-white/10 text-white font-semibold text-xs rounded-xl">
            Book Boarding
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
          <h2 className="font-bold text-sm text-slate-800">My Boarded Pets Telemetry</h2>
          {telemetry.map((t) => (
            <div key={t.petId} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between font-bold">
                <span>{t.petName}</span>
                <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px]">{t.roomNumber}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-white p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">Pulse</span>
                  <span className="font-bold">{t.heartRate} bpm</span>
                </div>
                <div className="bg-white p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">Temp</span>
                  <span className="font-bold">{t.bodyTemp}°C</span>
                </div>
                <div className="bg-white p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">State</span>
                  <span className="font-bold">{t.activityLevel}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <h2 className="font-bold text-sm text-slate-800">Invoices & Billing</h2>
          {invoices.map((inv) => (
            <div key={inv.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex justify-between items-center">
              <div>
                <span className="font-mono font-bold">{inv.invoiceNumber}</span>
                <div className="text-slate-500 text-[11px]">${inv.total.toFixed(2)} • {inv.petName}</div>
              </div>
              {inv.status === 'Paid' ? (
                <span className="text-emerald-700 font-bold text-[11px]">Paid</span>
              ) : (
                <button
                  onClick={() => handlePay(inv.id)}
                  className="px-3 py-1 bg-teal-600 text-white rounded-lg font-bold text-[11px]"
                >
                  Pay Now
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
