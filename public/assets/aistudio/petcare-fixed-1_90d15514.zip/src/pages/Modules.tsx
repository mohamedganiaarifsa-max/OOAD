import React, { useState } from 'react';
import { DataService, AuthService } from '../services';
import { useAuth } from '../AuthContext';
import { Pet, Booking, FeedingSchedule, Medication, Vaccination, GroomingAppointment, MedicalRecord, Invoice, UserRole } from '../types';
import {
  PawPrint,
  Plus,
  Trash2,
  Eye,
  X,
  Search,
  Home,
  UtensilsCrossed,
  Check,
  Pill,
  Syringe,
  Scissors,
  FileText,
  Activity,
  CreditCard,
  BarChart3,
  Users2,
  Bell,
  HeartPulse,
  RotateCcw,
} from 'lucide-react';

// 1. Pet Management
export const PetManagement: React.FC = () => {
  const { user } = useAuth();
  const [pets, setPets] = useState(() => DataService.getPets());
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [species, setSpecies] = useState<'Dog' | 'Cat' | 'Bird' | 'Rabbit' | 'Other'>('Dog');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState(3);
  const [weight, setWeight] = useState(15);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    DataService.addPet({
      name,
      species,
      breed,
      age: Number(age),
      gender: 'Male',
      weight: Number(weight),
      ownerId: user?.id || 'usr_owner_01',
      ownerName: user?.name || 'David & Clara Miller',
      ownerPhone: '+1 (555) 234-5678',
      microchipId: `985-${Math.floor(1000 + Math.random() * 9000)}-A`,
      avatarUrl: species === 'Cat'
        ? 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=300'
        : 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=300',
      isBoarded: false,
    });
    setPets(DataService.getPets());
    setShowAdd(false);
    setName('');
    setBreed('');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete pet profile?')) {
      DataService.deletePet(id);
      setPets(DataService.getPets());
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-800">Pet Directory & Profiles</h1>
          <p className="text-xs text-slate-500">Comprehensive patient records and microchip tracking.</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Add Pet
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {pets.map((p) => (
          <div key={p.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden p-4 space-y-3">
            <div className="flex items-center gap-3">
              <img src={p.avatarUrl} alt={p.name} className="w-14 h-14 rounded-xl object-cover" />
              <div>
                <h3 className="font-bold text-sm text-slate-800">{p.name}</h3>
                <span className="text-xs text-slate-500">{p.species} • {p.breed}</span>
                <span className="text-[10px] text-slate-400 font-mono block">Chip: {p.microchipId}</span>
              </div>
            </div>
            <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-100">
              <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${p.isBoarded ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                {p.isBoarded ? `Boarded (${p.roomNumber || 'Suite'})` : 'At Home'}
              </span>
              <button onClick={() => handleDelete(p.id)} className="text-slate-400 hover:text-rose-600">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3">
            <div className="flex justify-between items-center">
              <h2 className="font-bold text-sm">Register New Pet</h2>
              <button onClick={() => setShowAdd(false)}><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAdd} className="space-y-3 text-xs">
              <input required placeholder="Pet Name" value={name} onChange={(e) => setName(e.target.value)} className="w-full p-2 bg-slate-50 border rounded-xl" />
              <select value={species} onChange={(e) => setSpecies(e.target.value as any)} className="w-full p-2 bg-slate-50 border rounded-xl">
                <option value="Dog">Dog</option>
                <option value="Cat">Cat</option>
                <option value="Other">Other</option>
              </select>
              <input required placeholder="Breed" value={breed} onChange={(e) => setBreed(e.target.value)} className="w-full p-2 bg-slate-50 border rounded-xl" />
              <div className="grid grid-cols-2 gap-2">
                <input type="number" required placeholder="Age" value={age} onChange={(e) => setAge(Number(e.target.value))} className="w-full p-2 bg-slate-50 border rounded-xl" />
                <input type="number" step="0.1" required placeholder="Weight (kg)" value={weight} onChange={(e) => setWeight(Number(e.target.value))} className="w-full p-2 bg-slate-50 border rounded-xl" />
              </div>
              <button type="submit" className="w-full py-2 bg-teal-600 text-white font-bold rounded-xl">Save Pet</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// 2. Booking & Boarding
export const BookingBoarding: React.FC = () => {
  const [bookings, setBookings] = useState(() => DataService.getBookings());
  const pets = DataService.getPets();

  const handleStatus = (id: string, st: Booking['status']) => {
    DataService.updateBooking(id, { status: st });
    setBookings(DataService.getBookings());
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-800">Booking & Resort Boarding</h1>
          <p className="text-xs text-slate-500">Luxury kennel suites, cat condos, and reservation logs.</p>
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-400 font-bold uppercase border-b">
            <tr>
              <th className="p-3">Guest</th>
              <th className="p-3">Room</th>
              <th className="p-3">Stay Dates</th>
              <th className="p-3">Rate</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {bookings.map((b) => (
              <tr key={b.id} className="hover:bg-slate-50">
                <td className="p-3 font-bold">{b.petName}</td>
                <td className="p-3 font-mono">{b.roomNumber} ({b.roomType})</td>
                <td className="p-3 text-slate-500">{b.checkInDate} → {b.checkOutDate}</td>
                <td className="p-3 font-bold">${b.dailyRate}/nt</td>
                <td className="p-3">
                  <select
                    value={b.status}
                    onChange={(e) => handleStatus(b.id, e.target.value as any)}
                    className="p-1 border rounded text-[11px]"
                  >
                    <option value="Confirmed">Confirmed</option>
                    <option value="Checked-In">Checked-In</option>
                    <option value="Completed">Completed</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// 3. Feeding Schedule
export const FeedingScheduleView: React.FC = () => {
  const { user } = useAuth();
  const [feedings, setFeedings] = useState(() => DataService.getFeedings());

  const handleToggle = (id: string) => {
    DataService.toggleFeedingCompleted(id, user?.name || 'Staff');
    setFeedings(DataService.getFeedings());
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Feeding Schedules</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {feedings.map((f) => (
          <div key={f.id} className="p-4 rounded-2xl bg-white border border-slate-200 flex justify-between items-center text-xs">
            <div>
              <span className="font-bold text-slate-800 text-sm">{f.petName}</span> ({f.mealType} at {f.scheduledTime})
              <div className="text-slate-600 mt-1">{f.foodBrand} • {f.portionGrams} grams</div>
              {f.dietaryRestrictions && <div className="text-rose-600 font-medium mt-1">⚠️ {f.dietaryRestrictions}</div>}
            </div>
            <button
              onClick={() => handleToggle(f.id)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs ${
                f.isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-teal-600 text-white'
              }`}
            >
              {f.isCompleted ? 'Fed' : 'Serve Meal'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// 4. Medication Management
export const MedicationManagement: React.FC = () => {
  const [meds, setMeds] = useState(() => DataService.getMedications());

  const handleToggle = (id: string) => {
    DataService.toggleMedicationGiven(id);
    setMeds(DataService.getMedications());
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Medication Administration</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {meds.map((m) => (
          <div key={m.id} className="p-4 rounded-2xl bg-white border border-slate-200 flex justify-between items-center text-xs">
            <div>
              <span className="font-bold text-slate-800 text-sm">{m.name}</span>
              <span className="ml-2 font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded">{m.petName}</span>
              <div className="text-slate-500 mt-1">{m.dosage} • {m.frequency} ({m.route})</div>
            </div>
            <button
              onClick={() => handleToggle(m.id)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs ${
                m.isGivenToday ? 'bg-emerald-100 text-emerald-800' : 'bg-teal-600 text-white'
              }`}
            >
              {m.isGivenToday ? 'Given' : 'Administer'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// 5. Vaccination Management
export const VaccinationManagement: React.FC = () => {
  const vacs = DataService.getVaccinations();
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Vaccination Records</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {vacs.map((v) => (
          <div key={v.id} className="p-4 rounded-2xl bg-white border border-slate-200 text-xs space-y-1.5">
            <div className="flex justify-between font-bold">
              <span>{v.petName}</span>
              <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700">{v.status}</span>
            </div>
            <div className="font-semibold text-slate-800">{v.vaccineName}</div>
            <div className="text-slate-500">Given: {v.dateAdministered} | Due: <strong>{v.dueDate}</strong></div>
            <div className="text-slate-400 font-mono text-[10px]">Cert: {v.certificateId}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 6. Grooming Salon
export const GroomingManagement: React.FC = () => {
  const [groomings, setGroomings] = useState(() => DataService.getGroomings());

  const handleStatus = (id: string, st: GroomingAppointment['status']) => {
    DataService.updateGroomingStatus(id, st);
    setGroomings(DataService.getGroomings());
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Grooming & Spa Salon</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {groomings.map((g) => (
          <div key={g.id} className="p-4 rounded-2xl bg-white border border-slate-200 text-xs space-y-2">
            <div className="flex justify-between font-bold">
              <span>{g.petName}</span>
              <span className="text-teal-700">${g.price}</span>
            </div>
            <div className="text-slate-500">{g.services.join(', ')}</div>
            <div className="text-slate-400">{g.appointmentDate} at {g.appointmentTime}</div>
            <select
              value={g.status}
              onChange={(e) => handleStatus(g.id, e.target.value as any)}
              className="w-full p-1 border rounded text-[11px]"
            >
              <option value="Scheduled">Scheduled</option>
              <option value="In-Progress">In-Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        ))}
      </div>
    </div>
  );
};

// 7. Medical Records
export const MedicalRecordsView: React.FC = () => {
  const records = DataService.getMedicalRecords();
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Clinical Medical Records</h1>
      <div className="space-y-3">
        {records.map((r) => (
          <div key={r.id} className="p-4 rounded-2xl bg-white border border-slate-200 text-xs space-y-2">
            <div className="flex justify-between font-bold">
              <span className="text-sm">{r.petName}</span>
              <span className="font-mono text-slate-400">{r.date}</span>
            </div>
            <div className="text-teal-700 font-semibold">Diagnosis: {r.diagnosis}</div>
            <div className="text-slate-600">{r.treatmentPlan}</div>
            <div className="p-2 bg-slate-50 rounded flex gap-4 text-slate-500 text-[11px]">
              <span>Temp: <strong>{r.vitals.temperature}°C</strong></span>
              <span>HR: <strong>{r.vitals.heartRate} bpm</strong></span>
              <span>RR: <strong>{r.vitals.respiratoryRate}/min</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 8. Smart Care Monitor
export const SmartCareMonitor: React.FC = () => {
  const telemetry = DataService.getTelemetry();
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
        <h1 className="text-xl font-bold text-slate-800">Smart Care Monitor (Live IoT Sensors)</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {telemetry.map((t) => (
          <div key={t.petId} className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-bold text-sm">{t.petName}</span>
              <span className="font-mono text-[10px] bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded font-bold">
                {t.roomNumber}
              </span>
            </div>
            <div className="h-32 bg-slate-900 rounded-xl overflow-hidden relative flex items-center justify-center">
              <img
                src={t.petName === 'Barnaby' ? 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=400' : 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400'}
                alt={t.petName}
                className="w-full h-full object-cover opacity-75"
              />
              <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/60 text-white text-[10px] font-mono">
                LIVE CAM • {t.cameraStatus}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-slate-50 p-2 rounded">
                <span className="text-[10px] text-slate-400 block">Pulse</span>
                <span className="font-bold">{t.heartRate} bpm</span>
              </div>
              <div className="bg-slate-50 p-2 rounded">
                <span className="text-[10px] text-slate-400 block">Temp</span>
                <span className="font-bold">{t.bodyTemp}°C</span>
              </div>
              <div className="bg-slate-50 p-2 rounded">
                <span className="text-[10px] text-slate-400 block">Room</span>
                <span className="font-bold">{t.ambientTemp}°C</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 9. Invoices & Payments
export const InvoicesPayments: React.FC = () => {
  const [invoices, setInvoices] = useState(() => DataService.getInvoices());

  const handlePay = (id: string) => {
    DataService.markInvoicePaid(id, 'Credit Card');
    setInvoices(DataService.getInvoices());
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Invoices & Payments</h1>
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-400 font-bold uppercase border-b">
            <tr>
              <th className="p-3">Invoice #</th>
              <th className="p-3">Patient</th>
              <th className="p-3">Amount</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {invoices.map((inv) => (
              <tr key={inv.id}>
                <td className="p-3 font-mono font-bold">{inv.invoiceNumber}</td>
                <td className="p-3">{inv.petName} ({inv.ownerName})</td>
                <td className="p-3 font-bold">${inv.total.toFixed(2)}</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${inv.status === 'Paid' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                    {inv.status}
                  </span>
                </td>
                <td className="p-3 text-right">
                  {inv.status !== 'Paid' && (
                    <button onClick={() => handlePay(inv.id)} className="px-2.5 py-1 bg-emerald-600 text-white rounded font-bold">
                      Pay
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// 10. Reports & Analytics
export const ReportsAnalytics: React.FC = () => {
  const pets = DataService.getPets();
  const invoices = DataService.getInvoices();
  const total = invoices.reduce((s, i) => s + (i.status === 'Paid' ? i.total : 0), 0);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Reports & Analytics</h1>
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Net Income</span>
          <div className="text-xl font-black text-emerald-600 mt-1">${total.toFixed(2)}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Patients</span>
          <div className="text-xl font-black text-slate-800 mt-1">{pets.length}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200">
          <span className="text-[10px] uppercase font-bold text-slate-400">Suite Occupancy</span>
          <div className="text-xl font-black text-slate-800 mt-1">{Math.round((pets.filter(p => p.isBoarded).length / 12) * 100)}%</div>
        </div>
      </div>
    </div>
  );
};

// 11. User Management
export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState(() => AuthService.getAllUsers());
  const { resetDemoData } = useAuth();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-800">User Management (Admin)</h1>
          <p className="text-xs text-slate-500">Clinic staff rosters and RBAC credentials.</p>
        </div>
        <button
          onClick={() => {
            resetDemoData();
            setUsers(AuthService.getAllUsers());
            alert('Default accounts restored!');
          }}
          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Restore Demo Accounts
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-400 font-bold uppercase border-b">
            <tr>
              <th className="p-3">Name</th>
              <th className="p-3">Email</th>
              <th className="p-3">Role</th>
              <th className="p-3">Department</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((u) => (
              <tr key={u.id}>
                <td className="p-3 font-bold">{u.name}</td>
                <td className="p-3 font-mono text-slate-500">{u.email}</td>
                <td className="p-3 font-bold uppercase text-[10px]">{u.role}</td>
                <td className="p-3 text-slate-600">{u.department || u.specialization || 'General'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// 12. Notifications
export const NotificationsView: React.FC = () => {
  const notifs = DataService.getNotifications();
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">System Notifications</h1>
      <div className="space-y-3">
        {notifs.map((n) => (
          <div key={n.id} className="p-4 rounded-2xl bg-white border border-slate-200 text-xs flex items-center gap-3">
            <Bell className="w-4 h-4 text-teal-600 shrink-0" />
            <div>
              <div className="font-bold text-slate-800">{n.title}</div>
              <div className="text-slate-500 text-[11px]">{n.message}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
