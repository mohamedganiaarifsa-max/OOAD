/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth, ProtectedRoute } from './AuthContext';
import { Navbar, Sidebar } from './Navigation';

// Login Pages
import {
  UniversalLoginPage,
  AdminLoginPage,
  DoctorLoginPage,
  StaffLoginPage,
  OwnerLoginPage,
} from './pages/LoginPage';

// Role Dashboards
import {
  AdminDashboard,
  DoctorDashboard,
  StaffDashboard,
  OwnerDashboard,
} from './pages/Dashboards';

// Module Pages
import {
  PetManagement,
  BookingBoarding,
  FeedingScheduleView,
  MedicationManagement,
  VaccinationManagement,
  GroomingManagement,
  MedicalRecordsView,
  SmartCareMonitor,
  InvoicesPayments,
  ReportsAnalytics,
  UserManagement,
  NotificationsView,
} from './pages/Modules';

const AppContent: React.FC = () => {
  const { currentPath, user, isAuthenticated } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Determine if on login route
  const isLoginPage =
    currentPath === '/login' ||
    currentPath === '/admin/login' ||
    currentPath === '/doctor/login' ||
    currentPath === '/staff/login' ||
    currentPath === '/owner/login' ||
    (!isAuthenticated && currentPath === '/');

  if (isLoginPage) {
    if (currentPath === '/admin/login') return <AdminLoginPage />;
    if (currentPath === '/doctor/login') return <DoctorLoginPage />;
    if (currentPath === '/staff/login') return <StaffLoginPage />;
    if (currentPath === '/owner/login') return <OwnerLoginPage />;
    return <UniversalLoginPage />;
  }

  const renderMainView = () => {
    switch (currentPath) {
      // Dashboards
      case '/admin/dashboard':
        return <ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>;
      case '/doctor/dashboard':
        return <ProtectedRoute allowedRoles={['doctor']}><DoctorDashboard /></ProtectedRoute>;
      case '/staff/dashboard':
        return <ProtectedRoute allowedRoles={['staff']}><StaffDashboard /></ProtectedRoute>;
      case '/owner/dashboard':
        return <ProtectedRoute allowedRoles={['owner']}><OwnerDashboard /></ProtectedRoute>;

      // Modules
      case '/pets':
        return <ProtectedRoute><PetManagement /></ProtectedRoute>;
      case '/boarding':
        return <ProtectedRoute><BookingBoarding /></ProtectedRoute>;
      case '/feeding':
        return <ProtectedRoute><FeedingScheduleView /></ProtectedRoute>;
      case '/medications':
        return <ProtectedRoute><MedicationManagement /></ProtectedRoute>;
      case '/vaccinations':
        return <ProtectedRoute><VaccinationManagement /></ProtectedRoute>;
      case '/grooming':
        return <ProtectedRoute><GroomingManagement /></ProtectedRoute>;
      case '/records':
        return <ProtectedRoute><MedicalRecordsView /></ProtectedRoute>;
      case '/smart-monitor':
        return <ProtectedRoute><SmartCareMonitor /></ProtectedRoute>;
      case '/invoices':
        return <ProtectedRoute><InvoicesPayments /></ProtectedRoute>;
      case '/reports':
        return <ProtectedRoute allowedRoles={['admin', 'doctor']}><ReportsAnalytics /></ProtectedRoute>;
      case '/users':
        return <ProtectedRoute allowedRoles={['admin']}><UserManagement /></ProtectedRoute>;
      case '/notifications':
        return <ProtectedRoute><NotificationsView /></ProtectedRoute>;

      default:
        if (user?.role === 'admin') return <ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>;
        if (user?.role === 'doctor') return <ProtectedRoute allowedRoles={['doctor']}><DoctorDashboard /></ProtectedRoute>;
        if (user?.role === 'staff') return <ProtectedRoute allowedRoles={['staff']}><StaffDashboard /></ProtectedRoute>;
        if (user?.role === 'owner') return <ProtectedRoute allowedRoles={['owner']}><OwnerDashboard /></ProtectedRoute>;
        return <UniversalLoginPage />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased text-slate-800">
      <Navbar
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <div className="flex-1 flex">
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />

        <main className="flex-1 lg:pl-64 min-w-0 transition-all duration-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {renderMainView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
