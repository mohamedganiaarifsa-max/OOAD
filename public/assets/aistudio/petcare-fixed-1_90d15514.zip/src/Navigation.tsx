import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { DataService } from './services';
import { UserRole } from './types';
import {
  PawPrint,
  Bell,
  LogOut,
  KeyRound,
  Shield,
  Stethoscope,
  Users,
  HeartHandshake,
  Menu,
  X,
  RotateCcw,
  LayoutDashboard,
  Home,
  UtensilsCrossed,
  Pill,
  Syringe,
  Scissors,
  FileText,
  Activity,
  CreditCard,
  BarChart3,
  Users2,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

export const DemoCredentialsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSelect?: (e: string, p: string) => void;
}> = ({ isOpen, onClose, onSelect }) => {
  const { login, resetDemoData } = useAuth();
  if (!isOpen) return null;

  const demoAccounts = [
    { role: 'admin' as UserRole, title: 'Administrator', email: 'admin@petcare.com', pass: 'admin123', icon: <Shield className="w-4 h-4 text-rose-600" /> },
    { role: 'doctor' as UserRole, title: 'Doctor / Vet', email: 'doctor@petcare.com', pass: 'doctor123', icon: <Stethoscope className="w-4 h-4 text-emerald-600" /> },
    { role: 'staff' as UserRole, title: 'Care Staff', email: 'staff@petcare.com', pass: 'staff123', icon: <Users className="w-4 h-4 text-blue-600" /> },
    { role: 'owner' as UserRole, title: 'Pet Owner', email: 'owner@petcare.com', pass: 'owner123', icon: <HeartHandshake className="w-4 h-4 text-amber-600" /> },
  ];

  const handlePick = (e: string, p: string) => {
    if (onSelect) onSelect(e, p);
    else login(e, p);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <h2 className="text-base font-bold text-slate-800">Demo Login Accounts</h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          {demoAccounts.map((d) => (
            <div key={d.role} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  {d.icon}
                  <span className="font-bold text-xs text-slate-800">{d.title}</span>
                </div>
                <div className="text-[11px] font-mono text-slate-600 space-y-0.5">
                  <div>{d.email}</div>
                  <div>Pass: {d.pass}</div>
                </div>
              </div>
              <button
                onClick={() => handlePick(d.email, d.pass)}
                className="mt-3 w-full py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold rounded-lg transition"
              >
                Log In as {d.role.toUpperCase()}
              </button>
            </div>
          ))}
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={() => {
              if (window.confirm('Reset demo accounts and sample data?')) {
                resetDemoData();
                DataService.resetAllData();
                alert('Demo data restored!');
                onClose();
              }
            }}
            className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Demo Data
          </button>
          <button onClick={onClose} className="text-xs text-slate-500 hover:text-slate-700 font-medium">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export const Navbar: React.FC<{ onToggleSidebar?: () => void; isSidebarOpen?: boolean }> = ({
  onToggleSidebar,
  isSidebarOpen,
}) => {
  const { user, role, logout, navigate } = useAuth();
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [showNotif, setShowNotif] = useState(false);
  const notifications = DataService.getNotifications();
  const unread = notifications.filter((n) => !n.isRead).length;

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <button
              onClick={() => (role ? navigate(`/${role}/dashboard`) : navigate('/login'))}
              className="flex items-center gap-2.5 text-left"
            >
              <div className="w-9 h-9 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-sm">
                <PawPrint className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-base text-slate-800 tracking-tight block leading-tight">
                  PetCare <span className="text-[10px] uppercase font-bold text-teal-600">Smart</span>
                </span>
                <span className="hidden sm:block text-[10px] text-slate-400">Management System</span>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => setShowDemoModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-teal-50 text-teal-800 border border-teal-200 hover:bg-teal-100 transition"
            >
              <KeyRound className="w-3.5 h-3.5 text-teal-600" />
              <span className="hidden sm:inline">Demo Credentials</span>
              <span className="sm:hidden">Demo</span>
            </button>


            {role && (
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                {role}
              </span>
            )}

            <div className="relative">
              <button
                onClick={() => setShowNotif(!showNotif)}
                className="relative p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
              >
                <Bell className="w-4 h-4" />
                {unread > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full" />}
              </button>
              {showNotif && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-50 text-xs">
                  <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-100">
                    <span className="font-bold">Notifications</span>
                    <button onClick={() => DataService.markAllNotificationsRead()} className="text-[11px] text-teal-600">
                      Clear all
                    </button>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {notifications.map((n) => (
                      <div key={n.id} className="p-2 rounded-lg bg-slate-50 space-y-0.5">
                        <div className="font-semibold text-slate-800">{n.title}</div>
                        <div className="text-slate-500 text-[11px]">{n.message}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <img
                  src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200"
                />
                <button
                  onClick={() => logout()}
                  title="Logout"
                  className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigate('/login')}
                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg"
              >
                Log In
              </button>
            )}
          </div>
        </div>
      </header>
      <DemoCredentialsModal isOpen={showDemoModal} onClose={() => setShowDemoModal(false)} />
    </>
  );
};

export const Sidebar: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { role, currentPath, navigate, logout } = useAuth();

  const links = [
    { label: 'Role Dashboard', path: `/${role || 'admin'}/dashboard`, icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: 'Pet Management', path: '/pets', icon: <PawPrint className="w-4 h-4" /> },
    { label: 'Booking & Boarding', path: '/boarding', icon: <Home className="w-4 h-4" /> },
    { label: 'Feeding Schedules', path: '/feeding', icon: <UtensilsCrossed className="w-4 h-4" /> },
    { label: 'Medications', path: '/medications', icon: <Pill className="w-4 h-4" /> },
    { label: 'Vaccinations', path: '/vaccinations', icon: <Syringe className="w-4 h-4" /> },
    { label: 'Grooming Salon', path: '/grooming', icon: <Scissors className="w-4 h-4" /> },
    { label: 'Medical Records', path: '/records', icon: <FileText className="w-4 h-4" /> },
    { label: 'Smart Care Monitor', path: '/smart-monitor', icon: <Activity className="w-4 h-4" />, badge: 'LIVE' },
    { label: 'Invoices & Billing', path: '/invoices', icon: <CreditCard className="w-4 h-4" /> },
    { label: 'Reports & Analytics', path: '/reports', icon: <BarChart3 className="w-4 h-4" /> },
    ...(role === 'admin' ? [{ label: 'User Management', path: '/users', icon: <Users2 className="w-4 h-4" /> }] : []),
  ];

  const handleNav = (p: string) => {
    navigate(p);
    onClose();
  };

  return (
    <>
      {isOpen && <div onClick={onClose} className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden" />}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transition-transform lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } flex flex-col justify-between`}
      >
        <div className="p-4 space-y-1 overflow-y-auto flex-1">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Navigation Menu
          </div>
          {links.map((it) => {
            const active = currentPath === it.path;
            return (
              <button
                key={it.path}
                onClick={() => handleNav(it.path)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
                  active ? 'bg-teal-50 text-teal-800 border border-teal-200' : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={active ? 'text-teal-600' : 'text-slate-400'}>{it.icon}</span>
                  <span>{it.label}</span>
                </div>
                {it.badge && (
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 animate-pulse">
                    {it.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
          <button
            onClick={() => logout()}
            className="w-full flex items-center justify-center gap-1.5 py-2 px-3 text-xs text-rose-600 hover:bg-rose-50 font-semibold rounded-lg border border-rose-200/60 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
