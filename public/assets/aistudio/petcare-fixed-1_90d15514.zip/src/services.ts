import {
  User,
  UserRole,
  Pet,
  Booking,
  FeedingSchedule,
  Medication,
  Vaccination,
  GroomingAppointment,
  MedicalRecord,
  SmartCareTelemetry,
  NotificationItem,
  Invoice,
} from './types';

export interface AuthAccount extends User {
  passwordHash: string;
}

const STORAGE_USERS_KEY = 'petcare_registered_users_v2';
const STORAGE_SESSION_KEY = 'petcare_auth_session_v2';

export const DEFAULT_DEMO_ACCOUNTS: AuthAccount[] = [
  {
    id: 'usr_admin_01',
    email: 'admin@petcare.com',
    passwordHash: 'admin123',
    name: 'Dr. Sarah Jenkins',
    role: 'admin',
    department: 'Hospital Administration',
    phone: '+1 (555) 901-2244',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-01-01T08:00:00Z',
  },
  {
    id: 'usr_doctor_01',
    email: 'doctor@petcare.com',
    passwordHash: 'doctor123',
    name: 'Dr. Marcus Vance, DVM',
    role: 'doctor',
    specialization: 'Senior Veterinary Surgeon & Diagnostician',
    phone: '+1 (555) 832-1199',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-01-05T08:00:00Z',
  },
  {
    id: 'usr_staff_01',
    email: 'staff@petcare.com',
    passwordHash: 'staff123',
    name: 'Elena Rostova',
    role: 'staff',
    department: 'Boarding & Intensive Care Lead',
    phone: '+1 (555) 431-8822',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-01-10T08:00:00Z',
  },
  {
    id: 'usr_owner_01',
    email: 'owner@petcare.com',
    passwordHash: 'owner123',
    name: 'David & Clara Miller',
    role: 'owner',
    phone: '+1 (555) 234-5678',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-01-12T08:00:00Z',
  },
];

export class AuthService {
  public static initUsers(): AuthAccount[] {
    try {
      const stored = localStorage.getItem(STORAGE_USERS_KEY);
      if (!stored) {
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(DEFAULT_DEMO_ACCOUNTS));
        return DEFAULT_DEMO_ACCOUNTS;
      }
      let parsed: AuthAccount[];
      try {
        parsed = JSON.parse(stored);
        if (!Array.isArray(parsed) || parsed.length === 0) throw new Error();
      } catch {
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(DEFAULT_DEMO_ACCOUNTS));
        return DEFAULT_DEMO_ACCOUNTS;
      }

      let updated = false;
      const healedList = [...parsed];
      for (const demo of DEFAULT_DEMO_ACCOUNTS) {
        const idx = healedList.findIndex(
          (u) => u.email.trim().toLowerCase() === demo.email.trim().toLowerCase()
        );
        if (idx === -1) {
          healedList.push(demo);
          updated = true;
        } else if (
          healedList[idx].passwordHash !== demo.passwordHash ||
          healedList[idx].role !== demo.role
        ) {
          healedList[idx] = { ...healedList[idx], passwordHash: demo.passwordHash, role: demo.role };
          updated = true;
        }
      }
      if (updated) localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(healedList));
      return healedList;
    } catch {
      return DEFAULT_DEMO_ACCOUNTS;
    }
  }

  public static resetDemoAccounts(): void {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(DEFAULT_DEMO_ACCOUNTS));
    localStorage.removeItem('petcare_users');
    localStorage.removeItem('auth_user');
    localStorage.removeItem('user');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('petcare_session');
  }

  public static login(
    emailInput: string,
    passwordInput: string,
    expectedRole?: UserRole
  ): { success: boolean; user?: User; error?: string } {
    const email = (emailInput || '').trim().toLowerCase();
    const password = (passwordInput || '').trim();

    if (!email) return { success: false, error: 'Email address is required.' };
    if (!password) return { success: false, error: 'Password is required.' };

    const users = this.initUsers();
    const matched = users.find((u) => u.email.trim().toLowerCase() === email);

    if (!matched) {
      return { success: false, error: 'Invalid email or password. Please verify credentials.' };
    }
    if (matched.passwordHash !== password) {
      return { success: false, error: 'Invalid password. Please try again.' };
    }
    if (expectedRole && matched.role !== expectedRole) {
      const roleTitles: Record<UserRole, string> = {
        admin: 'Administrator',
        doctor: 'Doctor / Veterinarian',
        staff: 'Care Staff',
        owner: 'Pet Owner',
      };
      return {
        success: false,
        error: `This account has role "${roleTitles[matched.role]}". Please use the corresponding portal.`,
      };
    }

    const { passwordHash: _, ...safeUser } = matched;
    try {
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(safeUser));
    } catch (e) {
      console.error(e);
    }
    return { success: true, user: safeUser };
  }

  public static getCurrentSession(): User | null {
    try {
      const stored = localStorage.getItem(STORAGE_SESSION_KEY);
      if (!stored) return null;
      const user = JSON.parse(stored) as User;
      const valid: UserRole[] = ['admin', 'doctor', 'staff', 'owner'];
      if (!user || !user.id || !user.email || !valid.includes(user.role)) {
        this.logout();
        return null;
      }
      return user;
    } catch {
      this.logout();
      return null;
    }
  }

  public static logout(): void {
    localStorage.removeItem(STORAGE_SESSION_KEY);
    localStorage.removeItem('petcare_session');
    localStorage.removeItem('currentUser');
  }

  public static getAllUsers(): User[] {
    return this.initUsers().map(({ passwordHash: _, ...u }) => u);
  }

  public static addUser(newUser: Omit<AuthAccount, 'id' | 'createdAt'>): User {
    const list = this.initUsers();
    const user: AuthAccount = { ...newUser, id: `usr_${Date.now()}`, createdAt: new Date().toISOString() };
    list.push(user);
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(list));
    const { passwordHash: _, ...safe } = user;
    return safe;
  }

  public static deleteUser(id: string): boolean {
    if (id === 'usr_admin_01') return false;
    const list = this.initUsers().filter((u) => u.id !== id);
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(list));
    return true;
  }
}

// ------------------- Data Service -------------------

const INITIAL_PETS: Pet[] = [
  {
    id: 'pet_01',
    name: 'Barnaby',
    species: 'Dog',
    breed: 'Golden Retriever',
    age: 4,
    gender: 'Male',
    weight: 31.5,
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    ownerPhone: '+1 (555) 234-5678',
    microchipId: '985-1410-0921-A',
    avatarUrl: 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=300&auto=format&fit=crop&q=80',
    allergies: ['Chicken byproduct', 'Penicillin'],
    medicalNotes: 'Mild hip dysplasia history; requires low-impact exercise.',
    isBoarded: true,
    roomNumber: 'Suite 101',
    createdAt: '2025-01-15T10:00:00Z',
  },
  {
    id: 'pet_02',
    name: 'Cleo',
    species: 'Cat',
    breed: 'Scottish Fold',
    age: 2,
    gender: 'Female',
    weight: 3.8,
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    ownerPhone: '+1 (555) 234-5678',
    microchipId: '985-1410-8832-B',
    avatarUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=300&auto=format&fit=crop&q=80',
    allergies: ['Dust mites'],
    medicalNotes: 'Sensitive gastrointestinal tract. Sensitive stomach wet food only.',
    isBoarded: true,
    roomNumber: 'Cat Condo C-3',
    createdAt: '2025-02-01T14:30:00Z',
  },
  {
    id: 'pet_03',
    name: 'Thor',
    species: 'Dog',
    breed: 'Siberian Husky',
    age: 3,
    gender: 'Male',
    weight: 27.2,
    ownerId: 'usr_owner_02',
    ownerName: 'Sarah Connor',
    ownerPhone: '+1 (555) 443-9901',
    microchipId: '985-2239-0112-C',
    avatarUrl: 'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?w=300&auto=format&fit=crop&q=80',
    allergies: [],
    medicalNotes: 'Active; loves morning agility yard.',
    isBoarded: false,
    createdAt: '2025-02-10T09:15:00Z',
  },
  {
    id: 'pet_04',
    name: 'Luna',
    species: 'Cat',
    breed: 'Ragdoll',
    age: 1,
    gender: 'Female',
    weight: 4.1,
    ownerId: 'usr_owner_03',
    ownerName: 'Robert Vance',
    ownerPhone: '+1 (555) 778-3312',
    microchipId: '985-9981-4433-D',
    avatarUrl: 'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=300&auto=format&fit=crop&q=80',
    allergies: ['Soy'],
    medicalNotes: 'Routine wellness examination scheduled.',
    isBoarded: true,
    roomNumber: 'Cat Condo C-1',
    createdAt: '2025-02-18T11:00:00Z',
  },
  {
    id: 'pet_05',
    name: 'Cooper',
    species: 'Dog',
    breed: 'French Bulldog',
    age: 5,
    gender: 'Male',
    weight: 12.4,
    ownerId: 'usr_owner_04',
    ownerName: 'Emily Watson',
    ownerPhone: '+1 (555) 661-2288',
    microchipId: '985-4421-7766-E',
    avatarUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=300&auto=format&fit=crop&q=80',
    allergies: ['Beef protein'],
    medicalNotes: 'Brachycephalic syndrome; keep in climate-controlled temperature.',
    isBoarded: true,
    roomNumber: 'VIP Penthouse 202',
    createdAt: '2025-02-22T16:00:00Z',
  },
];

const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'bk_101',
    petId: 'pet_01',
    petName: 'Barnaby',
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    roomType: 'Deluxe Suite',
    roomNumber: 'Suite 101',
    checkInDate: '2026-10-06',
    checkOutDate: '2026-10-12',
    status: 'Checked-In',
    dailyRate: 65,
    specialInstructions: 'Morning walk in agility yard; brush coat daily.',
    emergencyContact: '+1 (555) 234-5679',
  },
  {
    id: 'bk_102',
    petId: 'pet_02',
    petName: 'Cleo',
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    roomType: 'Cat Condo',
    roomNumber: 'Cat Condo C-3',
    checkInDate: '2026-10-07',
    checkOutDate: '2026-10-11',
    status: 'Checked-In',
    dailyRate: 45,
    specialInstructions: 'Calming pheromone diffuser active.',
    emergencyContact: '+1 (555) 234-5679',
  },
  {
    id: 'bk_103',
    petId: 'pet_04',
    petName: 'Luna',
    ownerId: 'usr_owner_03',
    ownerName: 'Robert Vance',
    roomType: 'Cat Condo',
    roomNumber: 'Cat Condo C-1',
    checkInDate: '2026-10-08',
    checkOutDate: '2026-10-14',
    status: 'Checked-In',
    dailyRate: 45,
    emergencyContact: '+1 (555) 778-3313',
  },
  {
    id: 'bk_104',
    petId: 'pet_05',
    petName: 'Cooper',
    ownerId: 'usr_owner_04',
    ownerName: 'Emily Watson',
    roomType: 'VIP Penthouse',
    roomNumber: 'VIP Penthouse 202',
    checkInDate: '2026-10-09',
    checkOutDate: '2026-10-15',
    status: 'Checked-In',
    dailyRate: 85,
    emergencyContact: '+1 (555) 661-2289',
  },
];

const INITIAL_FEEDINGS: FeedingSchedule[] = [
  {
    id: 'fd_01',
    petId: 'pet_01',
    petName: 'Barnaby',
    mealType: 'Breakfast',
    scheduledTime: '08:00 AM',
    foodBrand: 'Royal Canin Golden Retriever Adult',
    portionGrams: 280,
    dietaryRestrictions: 'No chicken, add joint supplement oil',
    isCompleted: true,
    completedAt: '08:15 AM',
    staffName: 'Elena Rostova',
  },
  {
    id: 'fd_02',
    petId: 'pet_01',
    petName: 'Barnaby',
    mealType: 'Dinner',
    scheduledTime: '06:00 PM',
    foodBrand: 'Royal Canin Golden Retriever Adult',
    portionGrams: 280,
    dietaryRestrictions: 'No chicken',
    isCompleted: false,
  },
  {
    id: 'fd_03',
    petId: 'pet_02',
    petName: 'Cleo',
    mealType: 'Breakfast',
    scheduledTime: '08:30 AM',
    foodBrand: 'Hill\'s Science Diet Gastrointestinal Biome',
    portionGrams: 75,
    dietaryRestrictions: 'Sensitive stomach wet can only',
    isCompleted: true,
    completedAt: '08:35 AM',
    staffName: 'Elena Rostova',
  },
  {
    id: 'fd_04',
    petId: 'pet_05',
    petName: 'Cooper',
    mealType: 'Breakfast',
    scheduledTime: '08:15 AM',
    foodBrand: 'Purina Pro Plan Sensitive Salmon',
    portionGrams: 150,
    dietaryRestrictions: 'No beef protein',
    isCompleted: true,
    completedAt: '08:20 AM',
    staffName: 'Elena Rostova',
  },
];

const INITIAL_MEDICATIONS: Medication[] = [
  {
    id: 'med_01',
    petId: 'pet_01',
    petName: 'Barnaby',
    name: 'Carprofen (Rimadyl)',
    dosage: '75 mg chewable tablet',
    frequency: 'Once daily with breakfast',
    route: 'Oral',
    prescribedBy: 'Dr. Marcus Vance, DVM',
    startDate: '2026-10-01',
    endDate: '2026-10-15',
    isGivenToday: true,
    lastAdministered: 'Today, 08:15 AM',
    instructions: 'Administer with food.',
  },
  {
    id: 'med_02',
    petId: 'pet_02',
    petName: 'Cleo',
    name: 'FortiFlora Feline Probiotic',
    dosage: '1 sachet powder',
    frequency: 'Once daily with breakfast',
    route: 'Oral',
    prescribedBy: 'Dr. Marcus Vance, DVM',
    startDate: '2026-10-05',
    endDate: '2026-10-20',
    isGivenToday: true,
    lastAdministered: 'Today, 08:35 AM',
    instructions: 'Sprinkle over wet food.',
  },
  {
    id: 'med_03',
    petId: 'pet_05',
    petName: 'Cooper',
    name: 'Apoquel (Oclacitinib)',
    dosage: '5.4 mg tablet',
    frequency: 'Twice daily',
    route: 'Oral',
    prescribedBy: 'Dr. Marcus Vance, DVM',
    startDate: '2026-10-07',
    endDate: '2026-10-21',
    isGivenToday: false,
    instructions: 'Give in pill pocket.',
  },
];

const INITIAL_VACCINATIONS: Vaccination[] = [
  {
    id: 'vac_01',
    petId: 'pet_01',
    petName: 'Barnaby',
    vaccineName: 'Rabies 3-Year Vaccine',
    dateAdministered: '2024-05-12',
    dueDate: '2027-05-12',
    batchNumber: 'DEF-88392-RAB',
    administeredBy: 'Dr. Marcus Vance, DVM',
    status: 'Up to Date',
    certificateId: 'CERT-RAB-2024-019',
  },
  {
    id: 'vac_02',
    petId: 'pet_01',
    petName: 'Barnaby',
    vaccineName: 'DHPP (Distemper / Parvo)',
    dateAdministered: '2025-10-15',
    dueDate: '2026-10-15',
    batchNumber: 'VET-44912-DHPP',
    administeredBy: 'Dr. Marcus Vance, DVM',
    status: 'Due Soon',
    certificateId: 'CERT-DHPP-2025-412',
  },
  {
    id: 'vac_03',
    petId: 'pet_02',
    petName: 'Cleo',
    vaccineName: 'FVRCP (Feline Core 3-in-1)',
    dateAdministered: '2025-08-20',
    dueDate: '2026-08-20',
    batchNumber: 'FEL-99014-FVR',
    administeredBy: 'Dr. Marcus Vance, DVM',
    status: 'Overdue',
    certificateId: 'CERT-FVR-2025-110',
  },
];

const INITIAL_GROOMING: GroomingAppointment[] = [
  {
    id: 'grm_01',
    petId: 'pet_01',
    petName: 'Barnaby',
    ownerName: 'David & Clara Miller',
    services: ['Hydrobath', 'Nail Dremel', 'Ear Cleaning'],
    appointmentDate: '2026-10-10',
    appointmentTime: '10:30 AM',
    groomerName: 'Sarah Jenkins',
    status: 'Scheduled',
    price: 85,
  },
  {
    id: 'grm_02',
    petId: 'pet_04',
    petName: 'Luna',
    ownerName: 'Robert Vance',
    services: ['Lion Cut Styling', 'Sanitary Trim'],
    appointmentDate: '2026-10-09',
    appointmentTime: '02:00 PM',
    groomerName: 'Sarah Jenkins',
    status: 'In-Progress',
    price: 95,
  },
];

const INITIAL_MEDICAL_RECORDS: MedicalRecord[] = [
  {
    id: 'rec_01',
    petId: 'pet_01',
    petName: 'Barnaby',
    date: '2026-10-06',
    doctorName: 'Dr. Marcus Vance, DVM',
    doctorEmail: 'doctor@petcare.com',
    diagnosis: 'Pre-Boarding Clinical Exam & Stifle Stiffness',
    symptoms: 'Subtle reluctance when rising.',
    vitals: { temperature: 38.4, heartRate: 88, respiratoryRate: 22, weight: 31.5 },
    treatmentPlan: 'Maintain daily Carprofen 75mg.',
    followUpDate: '2026-10-14',
  },
  {
    id: 'rec_02',
    petId: 'pet_02',
    petName: 'Cleo',
    date: '2026-10-07',
    doctorName: 'Dr. Marcus Vance, DVM',
    doctorEmail: 'doctor@petcare.com',
    diagnosis: 'Mild Stress-Induced Dysbiosis',
    symptoms: 'Soft stool prior to arrival, otherwise hydrated.',
    vitals: { temperature: 38.6, heartRate: 144, respiratoryRate: 28, weight: 3.8 },
    treatmentPlan: 'Initiate FortiFlora daily sachet in prescription wet food.',
  },
];

const INITIAL_TELEMETRY: SmartCareTelemetry[] = [
  {
    petId: 'pet_01',
    petName: 'Barnaby',
    roomNumber: 'Suite 101',
    status: 'Normal',
    heartRate: 78,
    bodyTemp: 38.3,
    activityLevel: 'Resting',
    ambientTemp: 21.5,
    humidity: 48,
    lastSyncTime: 'Just now',
    cameraStatus: 'Online',
  },
  {
    petId: 'pet_02',
    petName: 'Cleo',
    roomNumber: 'Cat Condo C-3',
    status: 'Normal',
    heartRate: 138,
    bodyTemp: 38.5,
    activityLevel: 'Sleeping',
    ambientTemp: 22.1,
    humidity: 46,
    lastSyncTime: 'Just now',
    cameraStatus: 'Online',
  },
  {
    petId: 'pet_05',
    petName: 'Cooper',
    roomNumber: 'VIP Penthouse 202',
    status: 'Normal',
    heartRate: 92,
    bodyTemp: 38.5,
    activityLevel: 'Moderate',
    ambientTemp: 20.8,
    humidity: 45,
    lastSyncTime: 'Just now',
    cameraStatus: 'Online',
  },
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_01',
    title: 'Vaccine Due Soon: Barnaby',
    message: 'DHPP booster is due this week for Barnaby.',
    type: 'warning',
    timestamp: '10 mins ago',
    isRead: false,
    link: 'vaccinations',
  },
  {
    id: 'notif_02',
    title: 'Evening Medication Scheduled',
    message: 'Boarded patients require evening medication rounds.',
    type: 'info',
    timestamp: '45 mins ago',
    isRead: false,
    link: 'medications',
  },
];

const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv_01',
    invoiceNumber: 'INV-2026-1001',
    petId: 'pet_01',
    petName: 'Barnaby',
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    date: '2026-10-06',
    dueDate: '2026-10-13',
    items: [
      { description: 'Deluxe Suite Boarding (6 nights)', quantity: 6, unitPrice: 65, total: 390 },
      { description: 'Veterinary Admission Exam', quantity: 1, unitPrice: 75, total: 75 },
    ],
    subtotal: 465,
    tax: 37.2,
    total: 502.2,
    status: 'Paid',
    paymentMethod: 'Credit Card',
  },
  {
    id: 'inv_02',
    invoiceNumber: 'INV-2026-1002',
    petId: 'pet_02',
    petName: 'Cleo',
    ownerId: 'usr_owner_01',
    ownerName: 'David & Clara Miller',
    date: '2026-10-07',
    dueDate: '2026-10-14',
    items: [
      { description: 'Cat Condo Boarding (4 nights)', quantity: 4, unitPrice: 45, total: 180 },
    ],
    subtotal: 180,
    tax: 14.4,
    total: 194.4,
    status: 'Pending',
  },
];

function getStored<T>(key: string, initial: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return initial;
  }
}

function setStored<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(err);
  }
}

export class DataService {
  public static resetAllData(): void {
    setStored('petcare_pets_data_v2', INITIAL_PETS);
    setStored('petcare_bookings_data_v2', INITIAL_BOOKINGS);
    setStored('petcare_feedings_data_v2', INITIAL_FEEDINGS);
    setStored('petcare_medications_data_v2', INITIAL_MEDICATIONS);
    setStored('petcare_vaccinations_data_v2', INITIAL_VACCINATIONS);
    setStored('petcare_grooming_data_v2', INITIAL_GROOMING);
    setStored('petcare_records_data_v2', INITIAL_MEDICAL_RECORDS);
    setStored('petcare_telemetry_data_v2', INITIAL_TELEMETRY);
    setStored('petcare_notifications_data_v2', INITIAL_NOTIFICATIONS);
    setStored('petcare_invoices_data_v2', INITIAL_INVOICES);
  }

  public static getPets(): Pet[] {
    return getStored<Pet[]>('petcare_pets_data_v2', INITIAL_PETS);
  }
  public static addPet(pet: Omit<Pet, 'id' | 'createdAt'>): Pet {
    const pets = this.getPets();
    const newPet: Pet = { ...pet, id: `pet_${Date.now()}`, createdAt: new Date().toISOString() };
    pets.unshift(newPet);
    setStored('petcare_pets_data_v2', pets);
    return newPet;
  }
  public static deletePet(id: string): boolean {
    const pets = this.getPets().filter((p) => p.id !== id);
    setStored('petcare_pets_data_v2', pets);
    return true;
  }

  public static getBookings(): Booking[] {
    return getStored<Booking[]>('petcare_bookings_data_v2', INITIAL_BOOKINGS);
  }
  public static addBooking(booking: Omit<Booking, 'id'>): Booking {
    const list = this.getBookings();
    const item: Booking = { ...booking, id: `bk_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_bookings_data_v2', list);
    return item;
  }
  public static updateBooking(id: string, updates: Partial<Booking>): Booking | null {
    const list = this.getBookings();
    const idx = list.findIndex((b) => b.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...updates };
    setStored('petcare_bookings_data_v2', list);
    return list[idx];
  }

  public static getFeedings(): FeedingSchedule[] {
    return getStored<FeedingSchedule[]>('petcare_feedings_data_v2', INITIAL_FEEDINGS);
  }
  public static toggleFeedingCompleted(id: string, staffName: string): FeedingSchedule | null {
    const list = this.getFeedings();
    const idx = list.findIndex((f) => f.id === id);
    if (idx === -1) return null;
    const isCompleted = !list[idx].isCompleted;
    list[idx] = {
      ...list[idx],
      isCompleted,
      completedAt: isCompleted ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined,
      staffName: isCompleted ? staffName : undefined,
    };
    setStored('petcare_feedings_data_v2', list);
    return list[idx];
  }
  public static addFeeding(f: Omit<FeedingSchedule, 'id'>): FeedingSchedule {
    const list = this.getFeedings();
    const item: FeedingSchedule = { ...f, id: `fd_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_feedings_data_v2', list);
    return item;
  }

  public static getMedications(): Medication[] {
    return getStored<Medication[]>('petcare_medications_data_v2', INITIAL_MEDICATIONS);
  }
  public static toggleMedicationGiven(id: string): Medication | null {
    const list = this.getMedications();
    const idx = list.findIndex((m) => m.id === id);
    if (idx === -1) return null;
    const isGiven = !list[idx].isGivenToday;
    list[idx] = {
      ...list[idx],
      isGivenToday: isGiven,
      lastAdministered: isGiven ? `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : undefined,
    };
    setStored('petcare_medications_data_v2', list);
    return list[idx];
  }
  public static addMedication(m: Omit<Medication, 'id'>): Medication {
    const list = this.getMedications();
    const item: Medication = { ...m, id: `med_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_medications_data_v2', list);
    return item;
  }

  public static getVaccinations(): Vaccination[] {
    return getStored<Vaccination[]>('petcare_vaccinations_data_v2', INITIAL_VACCINATIONS);
  }
  public static addVaccination(v: Omit<Vaccination, 'id'>): Vaccination {
    const list = this.getVaccinations();
    const item: Vaccination = { ...v, id: `vac_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_vaccinations_data_v2', list);
    return item;
  }

  public static getGroomings(): GroomingAppointment[] {
    return getStored<GroomingAppointment[]>('petcare_grooming_data_v2', INITIAL_GROOMING);
  }
  public static updateGroomingStatus(id: string, status: GroomingAppointment['status']): GroomingAppointment | null {
    const list = this.getGroomings();
    const idx = list.findIndex((g) => g.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], status };
    setStored('petcare_grooming_data_v2', list);
    return list[idx];
  }
  public static addGrooming(g: Omit<GroomingAppointment, 'id'>): GroomingAppointment {
    const list = this.getGroomings();
    const item: GroomingAppointment = { ...g, id: `grm_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_grooming_data_v2', list);
    return item;
  }

  public static getMedicalRecords(): MedicalRecord[] {
    return getStored<MedicalRecord[]>('petcare_records_data_v2', INITIAL_MEDICAL_RECORDS);
  }
  public static addMedicalRecord(rec: Omit<MedicalRecord, 'id'>): MedicalRecord {
    const list = this.getMedicalRecords();
    const item: MedicalRecord = { ...rec, id: `rec_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_records_data_v2', list);
    return item;
  }

  public static getTelemetry(): SmartCareTelemetry[] {
    return getStored<SmartCareTelemetry[]>('petcare_telemetry_data_v2', INITIAL_TELEMETRY);
  }

  public static getNotifications(): NotificationItem[] {
    return getStored<NotificationItem[]>('petcare_notifications_data_v2', INITIAL_NOTIFICATIONS);
  }
  public static markNotificationRead(id: string): void {
    const list = this.getNotifications();
    const idx = list.findIndex((n) => n.id === id);
    if (idx !== -1) {
      list[idx].isRead = true;
      setStored('petcare_notifications_data_v2', list);
    }
  }
  public static markAllNotificationsRead(): void {
    const list = this.getNotifications().map((n) => ({ ...n, isRead: true }));
    setStored('petcare_notifications_data_v2', list);
  }

  public static getInvoices(): Invoice[] {
    return getStored<Invoice[]>('petcare_invoices_data_v2', INITIAL_INVOICES);
  }
  public static markInvoicePaid(id: string, paymentMethod: Invoice['paymentMethod']): Invoice | null {
    const list = this.getInvoices();
    const idx = list.findIndex((i) => i.id === id);
    if (idx === -1) return null;
    list[idx].status = 'Paid';
    list[idx].paymentMethod = paymentMethod || 'Credit Card';
    setStored('petcare_invoices_data_v2', list);
    return list[idx];
  }
  public static addInvoice(inv: Omit<Invoice, 'id'>): Invoice {
    const list = this.getInvoices();
    const item: Invoice = { ...inv, id: `inv_${Date.now()}` };
    list.unshift(item);
    setStored('petcare_invoices_data_v2', list);
    return item;
  }
}
