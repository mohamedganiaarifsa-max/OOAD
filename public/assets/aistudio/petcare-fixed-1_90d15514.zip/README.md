# PetCare – Smart Pet Take Care Management System

A production-ready React + TypeScript management system for veterinary clinics, pet hospitals, and luxury pet boarding resorts.

---

## 1. Verified Demo Credentials

All four role accounts are pre-configured, tested, and can be accessed either via their independent portals or the universal sign-in portal:

| Role | Email | Password | Role Key | Redirect Dashboard |
| :--- | :--- | :--- | :--- | :--- |
| **Administrator** | `admin@petcare.com` | `admin123` | `admin` | `/admin/dashboard` |
| **Veterinary Doctor** | `doctor@petcare.com` | `doctor123` | `doctor` | `/doctor/dashboard` |
| **Care Staff** | `staff@petcare.com` | `staff123` | `staff` | `/staff/dashboard` |
| **Pet Owner** | `owner@petcare.com` | `owner123` | `owner` | `/owner/dashboard` |

---

## 2. Authentication & Security Highlights

* **Unified Authentication Service (`AuthService`)**: One shared, robust login function handles all roles (`admin`, `doctor`, `staff`, `owner`) rather than divergent, error-prone login handlers.
* **Whitespace & Case Sanitization**: Accidental leading/trailing spaces in emails are automatically trimmed, and email strings are normalized to lowercase.
* **Independent Role Portals**: Dedicated login routes (`/admin/login`, `/doctor/login`, `/staff/login`, `/owner/login`) with role validation and quick autofill helpers.
* **Strict Route Protection (`ProtectedRoute`)**: Authenticated users are prevented from accessing other roles' dashboards. Attempted unauthorized access displays a detailed **Unauthorized Access** screen with instant one-click redirection to their own authorized dashboard.
* **Resilient Session & LocalStorage Handling**:
  * Demo credentials are automatically verified and healed on initial load without overwriting user-created accounts.
  * Corrupted or outdated session keys are detected and cleared safely without continuous reloading or redirect loops.
  * Easy "Reset Demo Data & Credentials" button available from the UI header, modals, and user management.
* **Persistent Sessions**: Page refreshes maintain active login status seamlessly.
* **Session Termination**: The Logout button thoroughly clears the session and safely routes users back to their respective login page.

---

## 3. Features & Modules

1. **Pet Management (`/pets`)**: Full patient directory, species filtering (Canine, Feline, Exotic), health cards, microchip IDs, and medical notes.
2. **Booking & Boarding (`/boarding`)**: Luxury suites, feline condos, check-in/out scheduling, room rates, and stay status tracking.
3. **Feeding Schedules (`/feeding`)**: Daily meal servings (Breakfast, Lunch, Dinner, Snack), gram portions, dietary/allergy warnings, and staff completion logging.
4. **Medication Management (`/medications`)**: Veterinary prescriptions, oral/topical/injection routes, dosages, and daily administration toggles.
5. **Vaccination Management (`/vaccinations`)**: Core immunization tracking (Rabies, DHPP, Bordetella), batch numbers, booster expiration alerts, and digital certificates.
6. **Grooming Salon (`/grooming`)**: Hydrotherapy baths, breed styling, claw therapy, time slots, and status workflows.
7. **Clinical Medical Records (`/records`)**: Attending veterinarian diagnoses, vital signs (Temperature, Heart Rate, Respiratory Rate, Weight), treatment regimens, and follow-up schedules.
8. **Smart Care Monitor (`/smart-monitor`)**: Real-time simulated IoT biometrics (cardiac pulse, body temperature, activity level) and suite climate telemetry (HVAC temp, humidity %, live camera feed).
9. **Invoices & Payments (`/invoices`)**: Itemized service billing, receipt previews, payment status tracking, and card settlement.
10. **Reports & Analytics (`/reports`)**: Clinic occupancy rates, net revenue charts, and species demographics.
11. **User Management (`/users`)**: Administrator-controlled staff directory, RBAC roles, and credential management.
12. **Notifications & Alerts (`/notifications`)**: Automated warnings for pending booster shots, scheduled meal times, and urgent patient care.

---

## 4. Installation and Run Instructions

### Prerequisites
* Node.js (version 18+ or 20+ recommended)
* npm (version 9+)

### Setup & Development

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```

Open your browser at `http://localhost:3000`.

### Production Build

```bash
# Build the production bundle
npm run build

# Preview the production build
npm run preview
```

## 5. Maintenance notes

- Client-side demo data is stored in the browser's local storage. Clearing browser site data will reset the demo state.
- The demo credentials are for local demonstration only. Do not use these hard-coded credentials or local-storage authentication for a production healthcare system.
- Use `npm install` followed by `npm run build` to validate the project before deployment.
